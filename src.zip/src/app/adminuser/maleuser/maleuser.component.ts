import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-maleuser',
  templateUrl: './maleuser.component.html',
  styleUrls: ['./maleuser.component.css']
})
export class MaleuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
