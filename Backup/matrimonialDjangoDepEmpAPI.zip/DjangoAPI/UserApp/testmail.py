
# pylint: disable=E1101
import sendgrid
import os
from sendgrid.helpers.mail import *
from django.http.response import JsonResponse

from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail



def testmail():

    message = Mail(
        from_email='admin@munamatrimonial.com',
        to_emails='innovationbd21@gmail.com',
        subject='Welcome',
        html_content='<strong>and easy to do anywhere, even with Python</strong>')
    try:
        #sg = SendGridAPIClient(SENDGRID_API_KEY='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')
        sg = SendGridAPIClient(os.environ.get('SENDGRID_API_KEY'))
        response = sg.send(message)
        print(response.status_code)
        print(response.body)
        print(response.headers)
    
    except Exception as e:
        return JsonResponse("Email sending error",safe=False)
        #print(e.message)