import xlrd
from UserApp.serializers import AdminUserSerializer,TempUserSerializer,MaleUserSerializer,FemaleUserSerializer,MatchingTableSerializer,PostSerializer
from django.http.response import JsonResponse

def excelimport():
    
    loc = ('UserApp/dummy.xls')
    
    # To open Workbook
    wb = xlrd.open_workbook(loc)
    sheet = wb.sheet_by_index(0)
     
    # For row 0 and column 0
    #print(sheet.cell_value(1, 1))
    for r in range(3,24):  #range(3,sheet.nrows-1)
    #r=4
        user_data = {'fullName': sheet.cell_value(r, 1),
            'nickName': sheet.cell_value(r, 2) if sheet.cell_value(r, 2) != '' else None,
            'gender': sheet.cell_value(r, 3),
            'address': sheet.cell_value(r, 4),
            'city': sheet.cell_value(r, 5),
            'state': sheet.cell_value(r, 6),
            'zip': sheet.cell_value(r, 7),
            'cellPhone': sheet.cell_value(r, 8),
            'workPhone': sheet.cell_value(r, 9) if sheet.cell_value(r, 9) != '' else None,
            'homePhone': sheet.cell_value(r, 10) if sheet.cell_value(r, 10) != '' else None,
            'email': sheet.cell_value(r, 11),
            'personalWebsite': sheet.cell_value(r, 12) if sheet.cell_value(r, 12) != '' else None,
            'birthYear' : sheet.cell_value(r, 14),
            'age': sheet.cell_value(r, 13),
            'height': sheet.cell_value(r, 15),
            'weight': sheet.cell_value(r, 16),
            'maritalStatus': sheet.cell_value(r, 19) if sheet.cell_value(r, 19) != '' else None,
            'children' : sheet.cell_value(r, 20),
            'highestEducation': sheet.cell_value(r, 33),
            'employed' : sheet.cell_value(r, 34),
            'income': sheet.cell_value(r, 37) if sheet.cell_value(r, 37) != '' else None,
            'immigrationStatus': sheet.cell_value(r, 38) if sheet.cell_value(r, 38) != '' else None,
            'religiousPractice': sheet.cell_value(r, 48),
            'beard': sheet.cell_value(r, 51) if sheet.cell_value(r, 51) != '' else None,
            'wear': sheet.cell_value(r, 52) if sheet.cell_value(r, 52) != '' else None,
            'smoker': sheet.cell_value(r, 53) if sheet.cell_value(r, 53) != '' else None,
            'preReligious': sheet.cell_value(r, 54) if sheet.cell_value(r, 54) != '' else None,
            'preWear': sheet.cell_value(r, 56) if sheet.cell_value(r, 56) != '' else None,
            'preBeard': sheet.cell_value(r, 57) if sheet.cell_value(r, 57) != '' else None,
            'preSmoking': sheet.cell_value(r, 58) if sheet.cell_value(r, 58) != '' else None,
            'preEthnicSpecific': sheet.cell_value(r, 59) if sheet.cell_value(r, 59) != '' else None,
            'preImmigrationStatus': sheet.cell_value(r, 60) if sheet.cell_value(r, 60) != '' else None,
            'preMaritalStatus': sheet.cell_value(r, 61) if sheet.cell_value(r, 61) != '' else None,
            'preChildren': sheet.cell_value(r, 62) if sheet.cell_value(r, 62) != '' else None,
            'preEducation':sheet.cell_value(r, 63) if sheet.cell_value(r, 63) != '' else None,
            'preEmployment':sheet.cell_value(r, 64) if sheet.cell_value(r, 64) != '' else None,
            'preIncome':sheet.cell_value(r, 65) if sheet.cell_value(r, 65) != '' else None,
            'preAgeGap':sheet.cell_value(r, 66) if sheet.cell_value(r, 66) != '' else None,
            'userPass': 'VFZSSmVrNUJQVDA9',
            'matchShowLimit': 5,
            'status': 'Active'
        }

        if(user_data['gender'] == 'Male'):
            maleuser_serializer=MaleUserSerializer(data=user_data)
            if maleuser_serializer.is_valid():
                maleuser_serializer.save()
                #return JsonResponse("Added Successfully",safe=False)
            else:
                return JsonResponse("Failed to AddM",safe=False)
        else:
            femaleuser_serializer=FemaleUserSerializer(data=user_data)
            if femaleuser_serializer.is_valid():
                femaleuser_serializer.save()
                #return JsonResponse("Added Successfully",safe=False)
            else:
                return JsonResponse("Failed to AddF",safe=False)
    return JsonResponse("Added Successfully",safe=False)


    #birthdate = sheet.cell_value(r, 14)
    #if '-' in birthdate:
      #  bd = birthdate.split('-')
       # birthdate = bd[2]+'-'+bd[1]+'-'+bd[0]
    #else if '/' in birthdate:
      #  bd = birthdate.split('/')
      #  birthdate = bd[2]+'-'+bd[1]+'-'+bd[0]
