from django.db import models
from django.db.models.base import Model
from django.apps import apps
from UserApp.models import MaleUser,FemaleUser,MatchingTable
from django.http.response import JsonResponse
from rest_framework.parsers import JSONParser
import numpy as np
from UserApp.serializers import AdminUserSerializer,TempUserSerializer,MaleUserSerializer,FemaleUserSerializer,MatchingTableSerializer,PostSerializer
from UserApp.email import send_email
import operator
import os
import logging

def populate():

    	
	male= MaleUser.objects.all()
	female=FemaleUser.objects.all()

	
	match=MatchingTable.objects.all()

	x = dict()

	point=0
	malepoint=0
	femalepoint=0

	#Sum up total point for male & female
	for p in range(0,match.count()):
		if match[p].malePoint!=None:
			malepoint= malepoint + match[p].malePoint
		if match[p].femalePoint!=None:
			femalepoint= femalepoint + match[p].femalePoint


			
	return JsonResponse("Matching Done Successfully",safe=False)
