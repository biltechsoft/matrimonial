import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-matches',
  templateUrl: './top-matches.component.html',
  styleUrls: ['./top-matches.component.css']
})
export class TopMatchesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
