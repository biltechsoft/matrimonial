import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { ILogin } from 'app/interfaces/login';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {SharedService} from 'app/shared.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private service:SharedService,
              private router : Router
              ) { }
  test : Date = new Date();
  focus;
  focus1;
  TempList:any = [];
  currentUser;
  adminUser;
  veriCode="";
  wrongCode = false;
  gotTempList = false;
  gotUserList = false;
  userEmail="";
  password="";
  UserList:any = [];
  AdminUserList:any = [];
  MaleUserList:any = [];
  FemaleUserList:any = [];
  dummyvar="";
  errorMessage="";
  code = this.service.getRandomInt(123456,987654);




  ngOnInit(): void {
    localStorage.removeItem('forgot');
    if(localStorage.getItem('removeVeriCode') == "False") {
      localStorage.removeItem('removeVeriCode');
    }
    else {
      localStorage.removeItem('gotVeriCode');
    }
    //document.getElementById(this.userEmail).focus();
    this.refreshUserList();
  }

  isSignedUp() {
    if (localStorage.getItem('isSignedUp') == "True") {return true; }
    else {return false;}
  }
  gotVeriCode() {
    if (localStorage.getItem('gotVeriCode') == "True") {return true; }
    else {return false;}
  }
  enterPress() {
    if(this.gotVeriCode()) {
      this.clickVerify();
    }
    else {
      if(this.forgot()) {
        this.sendCode();
      } else {
        this.clickLogin();
      }
    }
  }
  clickLogin(passcheck=true) {
    //admin login part was here, now removed
    /*if(this.adminloginValidate(passcheck)) {
      localStorage.removeItem('isSignedUp');
      var UserToken = this.service.getRandomInt(12345678,87654321);
      localStorage.setItem('usertoken', UserToken);
      localStorage.setItem('adminid', this.adminUser.adminId);
      this.service.updateAdminUser({adminId: this.adminUser.adminId, adminToken: UserToken}).subscribe();
      localStorage.setItem('usertype', '0');
      localStorage.setItem('fromloginpage', 'True');
      localStorage.setItem('isLoggedOut','False');
      localStorage.setItem('username',this.adminUser.adminFullName);
      if(localStorage.getItem('forgot')=='True') {
        localStorage.removeItem('forgot');
        this.router.navigate(['/password']);
      }
      else {
        this.router.navigate(['/admin']);
      }
    }
    else */if(this.loginValidate(passcheck)) {
      localStorage.removeItem('isSignedUp');
      var UserToken = this.service.getRandomInt(12345678,87654321);
      localStorage.setItem('usertoken', UserToken);
      localStorage.setItem('userid', this.currentUser.userId);
      var usertype='';
      if(this.currentUser.gender == 'Male') {
        this.service.updateMaleUser({userId: this.currentUser.userId, userToken: UserToken}).subscribe();
        localStorage.setItem('usertype', '1');
        usertype='1';
      }
      else {
        this.service.updateFemaleUser({userId: this.currentUser.userId, userToken: UserToken}).subscribe();
        localStorage.setItem('usertype', '2');
        usertype='2';
      }
      localStorage.setItem('fromloginpage', 'True');
      localStorage.setItem('isLoggedOut','False');
      localStorage.setItem('username',this.currentUser.fullName);
      localStorage.setItem('userage',this.currentUser.age);
      if(localStorage.getItem('forgot')=='True') {
        localStorage.removeItem('forgot');
        this.router.navigate(['/password',usertype,this.currentUser.userId]);
      }
      else {
        this.router.navigate(['/user-profile',usertype,this.currentUser.userId]);
      }
    }
  }
  refreshUserList() {
    if(!this.gotUserList) {
      /*this.service.getAdminList().subscribe(data=>{
        this.AdminUserList = data;
      });*/
      this.service.getMaleUserList().subscribe(data=>{
        this.MaleUserList = data;
      });
      this.service.getFemaleUserList().subscribe(data=>{
        this.FemaleUserList= data;
      });
      this.gotUserList = true;
    }
  }
  loginValidate(passcheck=true) {
    this.currentUser = this.MaleUserList.find(e => e.email == this.userEmail.trim());
    if(this.currentUser == null) {
      this.currentUser = this.FemaleUserList.find(e => e.email == this.userEmail.trim());
      if(this.currentUser == null) {
        this.errorMessage = "Your Email is not Registered. Please Sign Up First.";
        return false;
      }
    }
    if(passcheck) {  //passcheck is false when forgot password, want to recover it
      if(this.currentUser.userPass == this.service.mEncrypt(this.password)) { return true; }
      //if(this.currentUser.userPass == this.password) { return true; }
      else {
        this.errorMessage = "Invalid Email or Password or Both";
        return false;
      }
    }
    else {return true;}
  }
  /*adminloginValidate(passcheck=true) {
    this.adminUser = this.AdminUserList.find(e => e.adminUserName == this.userEmail);
    if(this.adminUser != null) {
      if(passcheck) {  //passcheck is false when forgot password, want to recover it
        if(this.adminUser.adminPass == this.password) { return true; }
        else {
          this.errorMessage = "Invalid Email or Password or Both";
          return false;
        }
      }
      else {return true;}
    }
  }*/

  refreshTempList() {
    if(!this.gotTempList) {
      this.service.getTempList().subscribe(data=>{
        this.TempList = data;
      });
      this.gotTempList=true;
    }
  }
  verifyEmail() {
    if(this.forgot()) {
      return this.code == this.veriCode;
    }
    else {
      var cuser = this.TempList.filter(temp => temp.tempEmail==localStorage.getItem('userid'));

      //this.currentUser = this.TempList.find(e => e.tempEmail == localStorage.getItem('userid'))
      if(cuser == null) { return false; }
      else {
        this.currentUser = cuser[cuser.length-1];
        if(this.currentUser.tempVeriCode == this.veriCode) { this.wrongCode=false; return true; }
        else { return false; }
      }
    }
  }
  clickVerify() {
    if(!this.verifyEmail()) { this.wrongCode=true; return false; }
    if(this.forgot()) {
      this.clickLogin(false);
    }
    else {

        var val={
          fullName:this.currentUser.tempName,
          gender:this.currentUser.tempGender,
          state:this.currentUser.tempState,
          cellPhone:this.currentUser.tempCellPhone,
          email:this.currentUser.tempEmail,
          birthYear:this.currentUser.tempBirthYear,
          age:this.service.getAge(this.currentUser.tempBirthYear),
          matchShowLimit:5,
          userPass:this.currentUser.tempPass,
          status:"Inactive",
          photo:"anonymous.png",
          openingDate:this.service.getDateTime(),
          lastEdit:this.service.getDateTime(),
          gallery:'gallery1.jpg,gallery2.jpg,gallery3.jpg,gallery4.jpg'
        };
        if(this.currentUser.tempGender == "Male") {
          this.service.addMaleUser(val).subscribe(res=>{
          //alert(res.toString());
        });
      }
      else {
        this.service.addFemaleUser(val).subscribe(res=>{
          //alert(res.toString());
        });
      }
      this.service.deleteTempUser(this.currentUser.tempId).subscribe(res=>{
        //alert(res.toString());
      });
      localStorage.setItem('isSignedUp', "True");
      localStorage.removeItem('userid');
    }
    localStorage.removeItem('gotVeriCode');
    //this.router.navigate(['/login']);
  }
  clickForgot() {
    localStorage.setItem('forgot','True');
  }
  clickRemember() {
    localStorage.setItem('forgot','False');
  }
  emailValidate() {
    return this.service.validateEmail(this.userEmail);
  }
  forgot() {
    if(localStorage.getItem('forgot')=='True') {return true;}
    else {return false;}
  }
  sendCode() {
    /*if(this.adminloginValidate(false)) {
      localStorage.setItem('usertype','0');
    }
    else*/ if(!this.loginValidate(false)) {
      this.errorMessage = "Your Email is not registered! Please Sign Up.";
      return false;
    }
    var emailVal={
      subject: "Verification code from MUNA Matrimonial",
      message: "Your verification code is " + this.code,
      toEmail: [this.userEmail]
    }
    this.service.sendEmail(emailVal).subscribe(res=>{
      //alert(res.toString());
    });
    if(localStorage.getItem('usertype')=='0') {
      this.service.updateAdminUser({adminId: this.adminUser.adminId, adminPass: this.code}).subscribe();
    }
    else if(this.currentUser.gender == 'Male') {
      this.service.updateMaleUser({userId: this.currentUser.userId, userPass: this.service.mEncrypt(this.code)}).subscribe();
    }
    else {
      this.service.updateFemaleUser({userId: this.currentUser.userId, userPass: this.service.mEncrypt(this.code)}).subscribe();
    }
    localStorage.setItem('gotVeriCode','True');
    localStorage.setItem('removeVeriCode', "False");
  }


  /*isgreater() {
    this.OpeningDate='0001-01-11 00:00:00';
    this.LastEdit='0001-01-11 00:00:03';
    if(this.OpeningDate > this.LastEdit) {
      this.dummyvar="It Works";
    }
    else { this.dummyvar="It doesn't work. "; }
    return true;
  }*/

/*  createClick(){



      localStorage.setItem('isSignedUp', "true");
      this.router.navigate(['/login']);

      this.service.addMaleUser(val).subscribe(res=>{
        alert(res.toString());
      });


      var emailVal={
        subject: "Greetings from MUNA",
        message: "Your verification code is " + this.code,
        toEmail: [this.Email]
      }

      this.service.sendEmail(emailVal).subscribe(res=>{
        alert(res.toString());
      });
    }


  //fields of user table
  maleusers: any=  [];
  modalTitle="";

  MaleId=0;
  FemaleId=0;

  FullName=null;
  NickName=null;
  Gender=null;
  Address=null;
  City=null;
  State=null;
  Zip=null;
  CellPhone=null;
  WorkPhone=null;
  HomePhone=null;
  Email=null;
  PersonalWebsite=null;
  Age=null;
  DateOfBirth=null;
  Height=null;
  Weight=null;
  PlaceOfBirth=null;
  Health=null;
  MaritalStatus=null;
  Children=null;
  ChildrenNumber=null;
  ChildrenAges=null;
  ImmigrationStatus=null;
  HighSchool=null;
  HighSchoolYear=null;
  Bachelors=null;
  BachelorsYear=null;
  Masters=null;
  MastersYear=null;
  Doctorate=null;
  DoctorateYear=null;
  OtherDegree=null;
  OtherDegreeYear=null;
  Employed=null;
  Employment=null;
  Position=null;
  Income=null;
  ReligiousPractice=null;
  ReligiousPracticeBrief=null;
  RevertTime=null;

  Beard=null;
  Wear=null;

  Smoker=null;
  PreReligious=null;
  PreReligiousBrief=null;

  PreWear=null;
  preBeard=null;

  PreSmoking=null;
  PreEthnic=null;
  PreEthnicSpecific=null;
  PreImmigrationStatus=null;
  PreMaritalStatus=null;
  PreChildren=null;
  PreEducation=null;
  PreEmployment=null;
  PreIncome=null;
  PreAgeGap=null;
  GuarName=null;
  GuarAddress=null;
  GuarCity=null;
  GuarState=null;
  GuarCountry=null;
  GuarPhone=null;
  GuarEmail=null;
  GuarProfession=null;
  FamilyBrief=null;
  RefName1=null;
  RefRelation1=null;
  RefPhone1=null;
  RefName2=null;
  RefRelation2=null;
  RefPhone2=null;
  RefName3=null;
  RefRelation3=null;
  RefPhone3=null;
  Photo=null;
  Cv=null;
  Album=null;
  GovIssuedId=null;
  MatchShowLimit=5;
  UserPass=null;
  Status=null;
  OpeningDate = this.service.getDateTime();
  //OpeningDate=null;
  LastEdit=null;*/



}
