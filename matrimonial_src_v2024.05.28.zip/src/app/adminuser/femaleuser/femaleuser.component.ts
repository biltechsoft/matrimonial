import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-femaleuser',
  templateUrl: './femaleuser.component.html',
  styleUrls: ['./femaleuser.component.css']
})
export class FemaleuserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
